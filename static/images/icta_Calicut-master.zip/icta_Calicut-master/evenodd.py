num=int(input("Enter the number : "))
if(num%2==0):
    print("Even Number")
else:
    print("Odd Number")