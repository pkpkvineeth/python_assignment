def add(x,y):
    z=x+y
    print(z)
def sub(x,y):
    z=x-y
    print(z)
def mul(x,y):
    z=x*y
    print(z)
def div(x,y):
    z=x/y
    print(z)


    
num1=int(input("Enter the first number "))
num2=int(input("Enter the second number "))
add(num1,num2)
sub(num1,num2)
mul(num1,num2)
div(num1,num2)