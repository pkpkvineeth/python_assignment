a=input("Enter a Name : ")
print(a)