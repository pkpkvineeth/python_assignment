import time
import calendar

myTime=time.localtime(time.time())
print(myTime)


cal=calendar.month(2018,5)
print("Calendar")
print(cal)