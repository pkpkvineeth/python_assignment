a=int(input("Enter the 1st number : "))
b=int(input("Enter the 2nd number : "))
print(a)
print(b)
c=a+b

print(c)