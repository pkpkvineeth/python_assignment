print("Sum of 1st n number is : ")
n=int(input("Enter the limit : "))
i=1
sum=0
while(i<=n):
    sum=sum+i
    i=i+1
print(sum)