#myFile=open("hello.txt","w")
#myFile.write("ICTA Calicut full stack class")
#myFile.close()
#print("file grnerated successfully")


myFile=open("hello.txt","r")
s=myFile.read()
print(s)
myFile.close()

