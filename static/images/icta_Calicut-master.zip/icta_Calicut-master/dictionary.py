myDict={'name':'Raju','mobile':963258}
print(myDict)
print(myDict.keys())
print(myDict.values())