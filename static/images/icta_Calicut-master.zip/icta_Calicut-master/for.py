#for a in range(0,10):
#    print(a)
#fruits=["oranges","apple","mango"]
#for fruit in fruits:
#     print(fruit)
#for letter in'ICTA':
#    print(letter)
#for x in range(10,0,-1):
#    print(x)

mylist=[1,2,3,4,5,6]
for num in mylist:
    if(num%2==0):
        print(num)