a=float(input("Enter the 1st number : "))
b=float(input("Enter the 2nd number : "))
print(a)
print(b)
c=a*b
print("The Sum is :",c)