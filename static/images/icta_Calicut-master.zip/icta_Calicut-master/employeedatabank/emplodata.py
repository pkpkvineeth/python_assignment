def Employee():
    employee=[
        {
            'id':1,
            'name':'Sona',
            'salary':25000
        },
        {
            'id':2,
            'name':'Sonal',
            'salary':35000
        },
        {
            'id':3,
            'name':'Sana',
            'salary':50000
        },
        {
            'id':4,
            'name':'Hana',
            'salary':55000
        }
    ]
    return employee