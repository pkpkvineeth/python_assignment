num1=int(input("Enter a number : "))
if(num1<=10):
    print("number is less or equal to 10")
else:
    print("number is greater thn 10")