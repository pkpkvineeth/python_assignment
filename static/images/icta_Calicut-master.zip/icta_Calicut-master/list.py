mylist=["Rahul","Vishnu","Sabeer",23,49,38]
urlist=["Shamshil"]
#print(mylist)
#print(mylist[0])
#print(mylist[1:3])
#print(mylist[1:])
print(mylist+urlist)